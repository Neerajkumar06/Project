

// Function to handle Sign Up form submission
document.getElementById('signup-form').onsubmit = function (e) {
    e.preventDefault(); // Prevent the form from submitting

    var email = document.getElementById('signup-email').value;
    var password = document.getElementById('signup-password').value;

    // Check if the email is valid
    if (email === '' || !validateEmail(email)) {
        alert('Please enter a valid email or mobile number.');
        return; // Exit the function if there's an error
    }

    // Check if the password is filled
    if (password === '') {
        alert('Password cannot be blank.');
        return; // Exit the function if there's an error
    }

    alert('Sign Up Successful!'); // Placeholder for actual sign-up logic
};

// Function to handle Log In form submission
document.getElementById('login-form').onsubmit = function (e) {
    e.preventDefault(); // Prevent the form from submitting

    var email = document.getElementById('login-email').value;
    var password = document.getElementById('login-password').value;

    // Check if the email is valid
    if (email === '' || !validateEmail(email)) {
        alert('Please enter a valid email or mobile number.');
        return; // Exit the function if there's an error
    }

    // Check if the password is filled
    if (password === '') {
        alert('Password cannot be blank.');
        return; // Exit the function if there's an error
    }

    alert('Log In Successful!'); // Placeholder for actual login logic
};

// Function to switch to the Login page
document.getElementById('login-link').onclick = function () {
    document.querySelector('.form-container').style.display = 'none'; // Hide Sign Up
    document.getElementById('login-container').style.display = 'block'; // Show Log In
};

// Function to switch to the Sign Up page
document.getElementById('signup-link').onclick = function () {
    document.getElementById('login-container').style.display = 'none'; // Hide Log In
    document.querySelector('.form-container').style.display = 'block'; // Show Sign Up
};

// Simple email/mobile validation
function validateEmail(email) {
    // Basic pattern for email and a 10-digit mobile number
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || /^\d{10}$/.test(email);
}
